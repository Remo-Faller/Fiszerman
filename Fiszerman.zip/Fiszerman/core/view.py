import colorama

def head():
    print(colorama.Style.BRIGHT)
    print(colorama.Fore.CYAN + '''
                          '
                        '   ' 
                      '       '  youtube.com/@remofallerofficial - POLAND
                 .  '  .        '                        '
             '             '      '                   '   '

      .    '   '....'               ..'.      ' .
         '  .                     .     '          '     '  v1.2 FallerOS
               '  .  .  .  .  . '.    .'              '  .
                   '         '    '. '      Github: https://github.com/Remo-Faller
                     '       '      '       Strona: https://github.com/Remo-Faller/Fiszerman
                       ' .  '
                           ''')
    print(colorama.Fore.GREEN + 'Wejdź na http://0.0.0.0:5000/neptune aby zacząć')
