# COMPRESS APP --------------------------------------------------------------------------------------------------
COMPRESS_MIMETYPES = ['text/html', 'text/css', 'text/xml', 'application/json', 'application/javascript']
COMPRESS_LEVEL = 6
COMPRESS_MIN_SIZE = 500
# ---------------------------------------------------------------------------------------------------------------
# LOCAL CONFIGS--------------------------------------------------------------------------------------------------
DATABASE = "./database.db"
url = 'https://github.com/Remo-Faller/Fiszerman'
red = 'https://github.com/Remo-Faller/Fiszerman'
sta = 'x'
APP_SECRET_KEY = 'termux'
# ---------------------------------------------------------------------------------------------------------------
